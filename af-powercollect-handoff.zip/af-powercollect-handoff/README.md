# AF PowerCollect: تسليم إعادة التصميم (UX/UI)

**الفرع:** `design/premium-ui`، مبني فوق commit ‏`68848d0`.
**الحجم:** 14 commit، و64 ملف، والتعديلات كلها بالواجهة (resources + public/images + tailwind.config.js).

**ما في تعديلات على الباك إند:** لا controllers ولا migrations ولا routes ولا models. والاختبارات كلها ناجحة (171/171).

## محتويات المجلد
| الملف | الاستخدام |
|---|---|
| `af-premium-ui.patch` | كل الـ commits بملف واحد، وبيتطبق بـ `git am` |
| `af-premium-ui.bundle` | نفس الـ commits كحزمة git (بديل للـ patch) |
| `screenshots/before` | الشكل القديم |
| `screenshots/after` | الشكل الجديد |

## طريقة التطبيق (للمبرمج)
من جذر المستودع، وعلى `main` المحدّث:

```bash
git checkout -b design/premium-ui 68848d0      # أو من main الحالي
git am af-premium-ui.patch
npm install && npm run build
php artisan test
git push -u origin design/premium-ui          # ثم افتح Pull Request
```

أو باستخدام الـ bundle:

```bash
git fetch ./af-premium-ui.bundle design/premium-ui:design/premium-ui
```

> إذا تحرّك `main` بعد `68848d0` وصار تعارض، طبّق على `68848d0`، وبعدين اعمل `git merge main`.

## ملاحظات للفريق
- **الخطوط** بتنحمّل من Google Fonts: El Messiri، و Alexandria، و IBM Plex Sans Arabic.
- **الوضع الافتراضي فاتح.** الغامق اختياري، والاختيار بينحفظ بالمتصفح (`localStorage.theme`).
- **شعار جديد:** `public/images/logo-af.webp`، والشعار القديم `logo.png` لسا موجود بس ما عاد مستخدم.
- **مكوّنات جديدة:** `Icon`، و `ThemeToggle`، و `CommandPalette` (Ctrl+K)، و `CountUp`، و `DataTable/RowIdentity`. وفي hooks جديدة: `useResponsiveTables` و `useSpotlight`.
- **انحذف `StatRing`** لأنه ما عاد مستخدم.
- **صفحات الأخطاء:** `resources/views/errors/minimal.blade.php` صار مخصص بالعربي.

## بتحتاج قرار من الباك إند
1. قسم **"Circuit Breakers"** بنافذة الصلاحيات لسا بالإنجليزي، ومصدره `app/Enums/PermissionKey.php`. الأفضل يصير "القواطع".
2. **بطاقات الفلوس بلوحة التحكم** (تحصيل اليوم، الديون، المتأخرين) بتستنى بيانات الدفعات.
3. **تنبيه حجم الحزمة:** ملف JS الرئيسي صار 518KB (كان 495KB)، وعدّى حد تنبيه Vite اللي هو 500KB. هاد تنبيه مش خطأ، وسببه إن الصفحات بتنحمّل كلها مع بعض (`import.meta.glob(..., { eager: true })` بـ `app.jsx`). حلّه تحميل الصفحات عند الحاجة (lazy)، وهاد قرار معماري للفريق.
