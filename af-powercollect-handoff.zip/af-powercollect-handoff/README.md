# AF PowerCollect: تسليم إعادة التصميم (UX/UI)

**الفرع:** `design/premium-ui`، مبني فوق commit ‏`68848d0`.
**الحجم:** 18 commit، و88 ملف.

**الإصدار الثاني فيه إضافات بالباك إند للقراءة بس** (من غير migrations ولا تغيير بقاعدة البيانات):
- ‏2 controllers جداد: `LedgerController` و `BranchPerformanceController`.
- policy جديدة: `SubscriberTransactionPolicy`.
- ‏3 مسارات جديدة: `/ledger` و `/branch-performance` و `/branch-performance/{branch}`.
- الاختبارات كلها ناجحة (180/180).

التقرير الكامل: `ux-ui-report.html`.

## محتويات المجلد
| الملف | الاستخدام |
|---|---|
| `af-premium-ui.patch` | كل الـ commits بملف واحد، وبيتطبق بـ `git am` |
| `af-premium-ui.bundle` | نفس الـ commits كحزمة git (بديل للـ patch) |
| `af-updates.patch` | التحديثات (خط أكبر، ألوان الأزرار، الوضع المريح)، بتنطبق بعد `af-premium-ui.patch` بـ `git am` |
| `ux-ui-report.html` | تقرير UX/UI الكامل |
| `screenshots/before` | الشكل القديم |
| `screenshots/after` | الشكل الجديد (الإصدار الأول) |
| `screenshots/v2` | صور الإصدار الثاني |

## طريقة التطبيق (للمبرمج)
من جذر المستودع، وعلى `main` المحدّث:

```bash
git checkout -b design/premium-ui 68848d0      # أو من main الحالي
git am af-premium-ui.patch
npm install && npm run build
php artisan test
git push -u origin design/premium-ui          # ثم افتح Pull Request
```

أو باستخدام الـ bundle:

```bash
git fetch ./af-premium-ui.bundle design/premium-ui:design/premium-ui
```

> إذا تحرّك `main` بعد `68848d0` وصار تعارض، طبّق على `68848d0`، وبعدين اعمل `git merge main`.

## ملاحظات للفريق
- **الخطوط** بتنحمّل من Google Fonts: El Messiri، و Alexandria، و IBM Plex Sans Arabic.
- **الوضع الافتراضي فاتح.** الغامق اختياري، والاختيار بينحفظ بالمتصفح (`localStorage.theme`).
- **شعار جديد:** `public/images/logo-af.webp`، والشعار القديم `logo.png` لسا موجود بس ما عاد مستخدم.
- **مكوّنات جديدة:** `Icon`، و `ThemeToggle`، و `CommandPalette` (Ctrl+K)، و `CountUp`، و `DataTable/RowIdentity`. وفي hooks جديدة: `useResponsiveTables` و `useSpotlight`.
- **انحذف `StatRing`** لأنه ما عاد مستخدم.
- **صفحات الأخطاء:** `resources/views/errors/minimal.blade.php` صار مخصص بالعربي.

## بتحتاج قرار من الباك إند
1. قسم **"Circuit Breakers"** بنافذة الصلاحيات لسا بالإنجليزي، ومصدره `app/Enums/PermissionKey.php`. الأفضل يصير "القواطع".
2. **بطاقات الفلوس بلوحة التحكم** (تحصيل اليوم، الديون، المتأخرين) بتستنى بيانات الدفعات.
3. **تنبيه حجم الحزمة:** ملف JS الرئيسي صار 518KB (كان 495KB)، وعدّى حد تنبيه Vite اللي هو 500KB. هاد تنبيه مش خطأ، وسببه إن الصفحات بتنحمّل كلها مع بعض (`import.meta.glob(..., { eager: true })` بـ `app.jsx`). حلّه تحميل الصفحات عند الحاجة (lazy)، وهاد قرار معماري للفريق.

## بيانات تجريبية للسجل المالي (اختياري، محلياً بس)
```bash
php artisan db:seed --class=DemoActivitySeeder
```

## التحديثات (فرع `design/updates`)
بعد تطبيق `af-premium-ui.patch`:

```bash
git checkout -b design/updates
git am af-updates.patch
npm run build
```

التفاصيل بتقرير `AF-PowerCollect-تحديثات-الواجهة.pdf`.
